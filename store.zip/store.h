#pragma once
#include <string>
#include <vector>
#include<iostream>

using namespace std;

struct App
{
	string name;
	int rating;
	int price;
	string platform;
};

class Store
{
public:
	void addApp();
	void deleteApp();
	void displayApp(int appNumber);
	void displayAllApps();
private:
	vector<App> appList; 
	int getListSize();
};
