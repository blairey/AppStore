#include "store.h"

void Store::addApp()
{
	App app;
	
	cout << "Name:\n";
	cin >> app.name;
	cout << "Rating:\n";
	cin >>app.rating;
	cout << "Price:\n";
	cin >> app.price;
	cout << "Platform:\n";
	cin >> app.platform;

	appList.push_back(app);
}

int Store::getListSize()
{
	return appList.size();
}

void Store::displayApp(int appNumber)
{
	App app;
	app = appList[appNumber];
	cout << "number: "	<<	appNumber	<<	'\t';
	cout << "name: "	<<	app.name	<<	'\t';
	cout << "rating: "  <<	app.rating	<<	'\t';
	cout << "price: "   <<	app.price	<<	'\t';
	cout << "platform: "<<	app.platform<<	'\n';
	cout <<"---------------------------------------------------------------------" ;
}

void Store::displayAllApps()
{
	//todo add header
	for(int i = 0; i < appList.size(); i++)
	{
		displayApp(i);
		cout<<'\n';
	}
}